EE 435
Spring 2020
Dr. Famouri
Group 5 Design Project
Submitted by: Samuel Talkington and Corey Buchanan

NOTES:

	1. BEFORE RUNNING CIRCUIT, please first run filterCalculation.m in your MATLAB to generate filter values.
		1a. Not doing this will cause the circuit to be unable to run.

	2. Scope marked "Various Measurements" will provide plots shown in Results section of report.
	
	3. Scope marked "Pre-filtered inverter output waveform" will provide pulse width modulated inverter output.


Thanks for a great semester!
-Sam and Corey